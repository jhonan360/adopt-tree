
<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <div class="greennature-content">
            <!-- Above Sidebar Section-->

            <!-- Sidebar With Content Section-->
            <div class="with-sidebar-wrapper">
                <section id="content-section-1">
                    <div class="greennature-full-size-wrapper gdlr-show-all no-skin" style="padding-bottom: 0px;  background-color: #ffffff; ">
                        <div class="greennature-master-slider-item greennature-slider-item greennature-item" style="margin-bottom: 0px;">
                            <!-- MasterSlider -->
                            <div id="P_slider_1" class="master-slider-parent ms-parent-id-1">

                                <!-- MasterSlider Main -->
                                <div id="slider_1" class="master-slider ms-skin-default">

                                    <div class="ms-slide" data-delay="7" data-fill-mode="fill">
                                        <img src='<?php echo e(asset("plugins/masterslider/public/assets/css/blank.gif")); ?>' alt="" title="" data-src='<?php echo e(asset("upload/slider-1.jpg")); ?>' />

                                        

                                        <div class="ms-layer  msp-cn-1-3" style="" data-effect="t(true,150,n,n,n,n,n,n,n,n,n,n,n,n,n)" data-duration="437" data-delay="625" data-ease="easeOutQuint" data-offset-x="0" data-offset-y="105" data-origin="ml" data-position="normal">
                                            La tierra</div>

                                        <div class="ms-layer  msp-cn-1-2" style="" data-effect="t(true,150,n,n,n,n,n,n,n,n,n,n,n,n,n)" data-duration="425" data-delay="325" data-ease="easeOutQuint" data-offset-x="0" data-offset-y="-5" data-origin="ml" data-position="normal">
                                            Podemos sanar</div>

                                        <div class="ms-layer  msp-cn-1-1" style="" data-effect="t(true,150,n,n,n,n,n,n,n,n,n,n,n,n,n)" data-duration="350" data-ease="easeOutQuint" data-offset-x="0" data-offset-y="-100" data-origin="ml" data-position="normal">
                                            Juntos</div>

                                    </div>
                                    
                                    <div class="ms-slide" data-delay="7" data-fill-mode="fill">
                                        <img src='<?php echo e(asset("plugins/masterslider/public/assets/css/blank.gif")); ?>' alt="" title="" data-src='<?php echo e(asset("upload/slider-3.jpg")); ?>' />

                                        <div class="ms-layer  msp-cn-1-10" style="" data-effect="t(true,n,n,-500,n,n,n,n,n,n,n,n,n,n,n)" data-duration="425" data-delay="425" data-ease="easeOutQuint" data-offset-x="0" data-offset-y="82" data-origin="mc" data-position="normal">
                                            El Mejor Lugar</div>

                                        <div class="ms-layer  msp-cn-1-13" style="" data-effect="t(true,n,n,500,n,n,n,n,n,n,n,n,n,n,n)" data-duration="437" data-ease="easeOutQuint" data-offset-x="0" data-offset-y="-15" data-origin="mc" data-position="normal">
                                            Hacer Este Mundo</div>

                                    </div>

                                </div>
                                <!-- END MasterSlider Main -->

                            </div>
                            <!-- END MasterSlider -->


                        </div>
                        <div class="clear"></div>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </section>
                
            </div>
            <!-- Below Sidebar Section-->
        </div>
        <!-- greennature-content -->
        <div class="clear"></div>
    </div>
    <!-- content wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adopt-tree\resources\views/landing/home.blade.php ENDPATH**/ ?>