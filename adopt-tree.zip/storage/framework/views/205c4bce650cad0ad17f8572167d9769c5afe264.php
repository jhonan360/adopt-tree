
<?php $__env->startSection('contentBody'); ?>
    <style>
        #map_canvas {
            width: 900px;
            height: 500px;
        }
        #current {
            padding-top: 25px;
        }
    </style>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Planta</h1>
    </div>
    <div class="row" style="margin-bottom: 34px;">
        <div class="col-sm-12 col-md-3 col-lg-3 col-xl-3 col-12">
            <img 
                <?php if(isset($planta->multimedia[0])): ?>
                    <?php if(isset($planta->multimedia[0]->tipo) && $planta->multimedia[0]->tipo == 'imagen'): ?>
                        src="<?php echo e(asset('images/multimedia/')); ?><?php echo e($planta->multimedia[0]->nombre); ?>" 
                    <?php else: ?>
                        src="<?php echo e(asset('images/multimedia/default.png')); ?>" 
                    <?php endif; ?>
                <?php else: ?>
                    src="<?php echo e(asset('images/multimedia/default.png')); ?>" 
                <?php endif; ?>
                style="width: 100%;height: 100%;"
            >
        </div>
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 col-12">
            <section>
                <div id='map_canvas' style="width: 100%"></div>
            </section>
        </div>
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 col-12">
            <table>
                <tbody>
                    <tr>
                        <td>Nombre:</td>
                        <td><b><?php echo e($planta->nombre); ?></b></td>
                    </tr>
                    <tr>
                        <td>Nombre comun:</td>
                        <td><?php echo e($planta->nombrePlanta->nombre_comun); ?></td>
                    </tr>
                    <tr>
                        <td>Nombre cientifico:</td>
                        <td><?php echo e($planta->nombrePlanta->nombre_cientifico); ?></td>
                    </tr>
                    <tr>
                        <td>Tipo de planta:</td>
                        <td><?php echo e($planta->nombrePlanta->tipoPlanta->nombre); ?></td>
                    </tr>
                    <tr>
                        <td>Clima:</td>
                        <td><?php echo e($planta->nombrePlanta->clima->nombre); ?></td>
                    </tr>
                    <tr>
                        <td>Fecha ingreso:</td>
                        <td><?php echo e($planta->fecha_ingreso); ?></td>
                    </tr>
                    <tr>
                        <td>Fecha adopcion:</td>
                        <td><?php echo e($planta->fecha_adopcion); ?></td>
                    </tr>
                    <tr>
                        <td>Mensaje:</td>
                        <td><?php echo e($planta->mensaje); ?></td>
                    </tr>
                </tbody>
            </table>
            <?php if(@Auth::user()->hasRole('administrador')): ?>
                <h2>Cliente</h2>
                <table>
                    <tbody>
                        <tr>
                            <td>Nombres:</td>
                            <td><b><?php echo e($planta->user->nombre); ?></b></td>
                        </tr>
                        <tr>
                            <td>Apellidos:</td>
                            <td><?php echo e($planta->user->apellido); ?></td>
                        </tr>
                        <tr>
                            <td>Email:</td>
                            <td><?php echo e($planta->user->email); ?></td>
                        </tr>
                        <tr>
                            <td>Telefono:</td>
                            <td><?php echo e($planta->user->telefono); ?></td>
                        </tr>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class=" <?php if(isset($planta->multimedia[0])): ?> col-sm-6 col-md-6 col-lg-6 col-xl-6 col-6 <?php else: ?> col-sm-12 col-md-12 col-lg-12 col-xl-12 col-12  <?php endif; ?>">
            <h2>Bitacora</h2>
            <table class="table table-bordered" id="tabla">
                <thead>
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Usuario</th>
                    <th scope="col">Fecha Realización</th>
                    <th scope="col">Hora Riego</th>
                    <th scope="col">Poda</th>
                    <th scope="col">Quimicos</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $planta->bitacoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bitacora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($bitacora->user->nombre); ?> <?php echo e($bitacora->user->apellido); ?></td>
                            <td><?php echo e($bitacora->created_at); ?></td>
                            <td><?php echo e($bitacora->hora_riego ?? ''); ?></td>
                            <td><?php echo e($bitacora->poda = 0 ? 'NO' : 'SI'); ?></td>
                            <td>
                                <?php $__currentLoopData = $bitacora->quimicosHasBitacoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $qhb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p style="font-size: 12px">
                                        <?php echo e($qhb->cantidad); ?> <?php echo e($qhb->medida->nombre); ?> de <?php echo e($qhb->quimico->nombre); ?>

                                    </p>
                                    <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class=" <?php if(isset($planta->multimedia[0])): ?> col-sm-6 col-md-6 col-lg-6 col-xl-6 col-6 <?php else: ?> col-sm-12 col-md-12 col-lg-12 col-xl-12 col-12  <?php endif; ?>">
            <div class="row">
                <?php $__currentLoopData = $planta->multimedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $multi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 col-12">
                        <img src="<?php echo e(asset('images/multimedia/')); ?><?php echo e($multi->nombre); ?>"  class="foto-arbol">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAFkOsu7Q8aSe7u6XLzAKHDqN7Bq8BcvNk" async defer></script>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inScript'); ?>
    var map = new google.maps.Map(document.getElementById('map_canvas'), {
        zoom: 18,
        center: new google.maps.LatLng(<?php echo e($planta->latitud); ?>, <?php echo e($planta->longitud); ?>),
        mapTypeId: 'satellite'
    });

    var myMarker = new google.maps.Marker({
        position: new google.maps.LatLng(<?php echo e($planta->latitud); ?> , <?php echo e($planta->longitud); ?> ),
    });

    map.setCenter(myMarker.position);
    myMarker.setMap(map);
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adopt-tree\resources\views/dashboard/planta.blade.php ENDPATH**/ ?>