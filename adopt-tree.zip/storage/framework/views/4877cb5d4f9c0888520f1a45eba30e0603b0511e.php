
<?php $__env->startSection('contentBody'); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Adopciones</h1>
        
    </div>
    
    <div class="row">
        <div class="col-12">
        <table class="table table-bordered" id="tabla">
            <thead>
                <tr>
                <th scope="col">#</th>
                <th scope="col">ID</th>
                <th scope="col">Nombre Planta</th>
                <th scope="col">Nombre</th>
                <th scope="col">Nombre Cliente</th>
                <th scope="col">Fecha Adopcion</th>
                <th scope="col">Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $plantas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $planta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><?php echo e($planta->idplantas); ?></td>
                        <td><?php echo e($planta->nombrePlanta->nombre_comun); ?> <?php echo e($planta->nombrePlanta->nombre_cientifico); ?></td>
                        <td><?php echo e($planta->nombre); ?></td>
                        <td><?php echo e($planta->user->nombre); ?> <?php echo e($planta->user->apellido); ?></td>
                        <td><?php echo e($planta->fecha_adopcion); ?></td>
                        <td>
                            <a href="<?php echo e(route('planta',$planta->idplantas)); ?>"  class="btn btn-warning btn-icon-split">
                                <span class="icon text-white-50">
                                    <i class="fas fa-eye"></i>
                                </span>
                                <span class="text">Ver</span>    
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inScript'); ?>
    $(document).ready( function () {
        $('#tabla').DataTable();
    });
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adopt-tree\resources\views/dashboard/adopciones.blade.php ENDPATH**/ ?>