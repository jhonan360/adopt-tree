<!DOCTYPE html>
<!--[if IE 7]><html class="ie ie7 ltie8 ltie9" lang="en-US"><![endif]-->
<!--[if IE 8]><html class="ie ie8 ltie9" lang="en-US"><![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="en-US">
<!--<![endif]-->


<!-- index19:10 GMT -->
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="initial-scale=1.0" />

    <title><?php echo e(config('app.name')); ?></title>


    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Lato%3A100%2C100italic%2C300%2C300italic%2Cregular%2Citalic%2C700%2C700italic%2C900%2C900italic&amp;subset=latin&amp;' type='text/css' media='all' />
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Noto+Sans%3Aregular%2Citalic%2C700%2C700italic&amp;subset=greek%2Ccyrillic-ext%2Ccyrillic%2Clatin%2Clatin-ext%2Cvietnamese%2Cgreek-ext&amp;' type='text/css' media='all' />
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Merriweather%3A300%2C300italic%2Cregular%2Citalic%2C700%2C700italic%2C900%2C900italic&amp;subset=latin%2Clatin-ext&amp;' type='text/css' media='all' />
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Mystery+Quest%3Aregular&amp;subset=latin%2Clatin-ext&amp;' type='text/css' media='all' />


    <link rel='stylesheet' href='<?php echo e(asset("css/style.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo e(asset("plugins/superfish/css/superfish.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo e(asset("plugins/dl-menu/component.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo e(asset("plugins/font-awesome-new/css/font-awesome.min.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo e(asset("plugins/elegant-font/style.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo e(asset("plugins/fancybox/jquery.fancybox.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo e(asset("plugins/flexslider/flexslider.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo e(asset("css/style-responsive.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo e(asset("css/style-custom.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo e(asset("plugins/masterslider/public/assets/css/masterslider.main.css")); ?>' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo e(asset("css/master-custom.css")); ?>' type='text/css' media='all' />


</head>

<body data-rsssl=1 class="home page-template-default page page-id-5680 _masterslider _msp_version_3.2.7 woocommerce-no-js">
    <div class="body-wrapper  float-menu" data-home="https://demo.goodlayers.com/greennature/">
        <header class="greennature-header-wrapper header-style-5-wrapper greennature-header-with-top-bar">
            <!-- top navigation -->
            
            <div id="greennature-header-substitute"></div>
            <div class="greennature-header-inner header-inner-header-style-5">
                <div class="greennature-header-container container">
                    <div class="greennature-header-inner-overlay"></div>
                    <!-- logo -->
                    <div class="greennature-logo">
                        <div class="greennature-logo-inner">
                            <a href="index-2.html">
                                <img src="images/logo.png" alt="" /> </a>
                        </div>
                        <div class="greennature-responsive-navigation dl-menuwrapper" id="greennature-responsive-navigation">
                            <button class="dl-trigger">Open Menu</button>
                            <ul id="menu-main-menu" class="dl-menu greennature-main-mobile-menu">
                                <li class="menu-item menu-item-home current-menu-item page_item page-item-5680 current_page_item"><a href="index-2.html" aria-current="page">Inicio</a></li>
                                <li class="menu-item menu-item-has-children menu-item-15"><a href="#">Mapa</a></li>
                                <li class="menu-item menu-item-has-children"><a href="portfolio-grid-3-columns-no-space.html">Adoptar</a></li>
                                <li class="menu-item menu-item-has-children"><a href="blog-full-with-right-sidebar.html">Login</a></li>
                            </ul>
                        </div>
                    </div>

                    <!-- navigation -->
                    <div class="greennature-navigation-wrapper">
                        <nav class="greennature-navigation" id="greennature-main-navigation">
                            <ul id="menu-main-menu-1" class="sf-menu greennature-main-menu">
                                <li class="menu-item menu-item-home current-menu-item greennature-normal-menu"><a href="index-2.html"><i class="fa fa-home"></i>Inicio</a></li>
                                <li class="menu-item menu-item-has-children greennature-normal-menu"><a href="#" class="sf-with-ul-pre"><i class="fa fa-file-text-o"></i>Mapa</a></li>
                                <li class="menu-item menu-item-has-childrenmenu-item menu-item-has-children greennature-mega-menu"><a href="portfolio-grid-3-columns-no-space.html" class="sf-with-ul-pre"><i class="fa fa-globe"></i>Adoptar</a></li>
                                <li class="menu-item menu-item-has-childrenmenu-item menu-item-has-children greennature-normal-menu"><a href="blog-full-with-right-sidebar.html" class="sf-with-ul-pre">Login</a></li>
                            </ul>
                        </nav>
                        <div class="greennature-navigation-gimmick" id="greennature-navigation-gimmick"></div>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
        </header>
        <!-- is search -->
        <div class="content-wrapper">
            <div class="greennature-content">

                <!-- Above Sidebar Section-->

                <!-- Sidebar With Content Section-->
                <div class="with-sidebar-wrapper">
                    <section id="content-section-1">
                        <div class="greennature-full-size-wrapper gdlr-show-all no-skin" style="padding-bottom: 0px;  background-color: #ffffff; ">
                            <div class="greennature-master-slider-item greennature-slider-item greennature-item" style="margin-bottom: 0px;">
                                <!-- MasterSlider -->
                                <div id="P_slider_1" class="master-slider-parent ms-parent-id-1">

                                    <!-- MasterSlider Main -->
                                    <div id="slider_1" class="master-slider ms-skin-default">

                                        <div class="ms-slide" data-delay="7" data-fill-mode="fill">
                                            <img src='<?php echo e(asset("plugins/masterslider/public/assets/css/blank.gif")); ?>' alt="" title="" data-src='<?php echo e(asset("upload/slider-1.jpg")); ?>' />

                                            

                                            <div class="ms-layer  msp-cn-1-3" style="" data-effect="t(true,150,n,n,n,n,n,n,n,n,n,n,n,n,n)" data-duration="437" data-delay="625" data-ease="easeOutQuint" data-offset-x="0" data-offset-y="105" data-origin="ml" data-position="normal">
                                                La tierra</div>

                                            <div class="ms-layer  msp-cn-1-2" style="" data-effect="t(true,150,n,n,n,n,n,n,n,n,n,n,n,n,n)" data-duration="425" data-delay="325" data-ease="easeOutQuint" data-offset-x="0" data-offset-y="-5" data-origin="ml" data-position="normal">
                                                Podemos sanar</div>

                                            <div class="ms-layer  msp-cn-1-1" style="" data-effect="t(true,150,n,n,n,n,n,n,n,n,n,n,n,n,n)" data-duration="350" data-ease="easeOutQuint" data-offset-x="0" data-offset-y="-100" data-origin="ml" data-position="normal">
                                                Juntos</div>

                                        </div>
                                        
                                        <div class="ms-slide" data-delay="7" data-fill-mode="fill">
                                            <img src='<?php echo e(asset("plugins/masterslider/public/assets/css/blank.gif")); ?>' alt="" title="" data-src='<?php echo e(asset("upload/slider-3.jpg")); ?>' />

                                            <div class="ms-layer  msp-cn-1-10" style="" data-effect="t(true,n,n,-500,n,n,n,n,n,n,n,n,n,n,n)" data-duration="425" data-delay="425" data-ease="easeOutQuint" data-offset-x="0" data-offset-y="82" data-origin="mc" data-position="normal">
                                                El Mejor Lugar</div>

                                            <div class="ms-layer  msp-cn-1-13" style="" data-effect="t(true,n,n,500,n,n,n,n,n,n,n,n,n,n,n)" data-duration="437" data-ease="easeOutQuint" data-offset-x="0" data-offset-y="-15" data-origin="mc" data-position="normal">
                                                Hacer Este Mundo</div>

                                        </div>

                                    </div>
                                    <!-- END MasterSlider Main -->

                                </div>
                                <!-- END MasterSlider -->


                            </div>
                            <div class="clear"></div>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </section>
                    
                </div>
                <!-- Below Sidebar Section-->

            </div>
            <!-- greennature-content -->
            <div class="clear"></div>
        </div>
        <!-- content wrapper -->

        <footer class="footer-wrapper">
            <div class="footer-container container">
                <div class="footer-column three columns" id="footer-widget-1">
                    <div id="text-5" class="widget widget_text greennature-item greennature-widget">
                        <div class="textwidget">
                            <p><img src="upload/logo-light.png" style="width: 170px;" alt="" /></p>
                            <p>Adopt A Tree es una iniciativa para crear una fundación que obtiene árboles y realiza su respetivo mantenimiento, para que la ciudadanía pueda adoptar árboles.</p>
                        </div>
                    </div>
                </div>
                <div class="footer-column three columns" id="footer-widget-2">
                    <div id="text-9" class="widget widget_text greennature-item greennature-widget">
                        <h3 class="greennature-widget-title">Datos De Contacto</h3>
                        <div class="clear"></div>
                        <div class="textwidget"><span class="clear"></span><span class="greennature-space" style="margin-top: -6px; display: block;"></span> Address: Mariquita Tolima

                            <span class="clear"></span><span class="greennature-space" style="margin-top: 10px; display: block;"></span>

                            <i class="greennature-icon fa fa-phone" style="vertical-align: middle; color: #fff; font-size: 16px; "></i> +57 601 244 5164

                            <span class="clear"></span><span class="greennature-space" style="margin-top: 10px; display: block;"></span>

                            <i class="greennature-icon fa fa-mobile" style="vertical-align: middle; color: #fff; font-size: 20px; "></i> +57 300 111 2222

                            <span class="clear"></span><span class="greennature-space" style="margin-top: 10px; display: block;"></span>

                            <i class="greennature-icon fa fa-envelope-o" style="vertical-align: middle; color: #fff; font-size: 16px; "></i> contact@adoptatree.com</div>
                    </div>
                </div>
                <div class="clear"></div>
            </div>

            
        </footer>

        <div class="greennature-payment-lightbox-overlay" id="greennature-payment-lightbox-overlay"></div>
        <div class="greennature-payment-lightbox-container" id="greennature-payment-lightbox-container">
            <div class="greennature-payment-lightbox-inner">
                <form class="greennature-payment-form" id="greennature-payment-form" >
                    <h3 class="greennature-payment-lightbox-title">
				<span class="greennature-head">You are donating to :</span>
				<span class="greennature-tail">Greennature Foundation</span>
			</h3>

                    <div class="greennature-payment-amount">
                        <div class="greennature-payment-amount-head">How much would you like to donate?</div>
                        <a class="greennature-payment-price-preset greennature-active" data-val="10">$10</a>
                        <a class="greennature-payment-price-preset" data-val="20">$20</a>
                        <a class="greennature-payment-price-preset" data-val="30">$30</a>
                        <input class="greennature-payment-price-fill" type="text" placeholder="Or Your Amount(USD)" />
                        <input class="greennature-payment-price" type="hidden" name="amount" value="10" />

                        <input class="greennature-payment-price" type="hidden" name="a3" value="10">
                    </div>

                    <div class="greennature-paypal-attribute">
                        <span class="greennature-head">Would you like to make regular donations?</span>
                        <span class="greennature-subhead">I would like to make </span>
                        <select name="t3" class="greennature-recurring-option">
                            <option value="0">one time</option>
                            <option value="W">weekly</option>
                            <option value="M">monthly</option>
                            <option value="Y">yearly</option>
                        </select>
                        <span class="greennature-subhead">donation(s)</span>
                        <input type="hidden" name="p3" value="1" />
                        <div class="greennature-recurring-time-wrapper">
                            <span class="greennature-subhead">How many times would you like this to recur? (including this payment) *</span>
                            <select name="srt" class="greennature-recurring-option">
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                                <option value="10">10</option>
                                <option value="11">11</option>
                                <option value="12">12</option>
                            </select>
                        </div>
                        <input type="hidden" name="cmd" value="_xclick">
                        <input type="hidden" name="bn" value="PP-BuyNowBF">
                        <input type="hidden" name="src" value="1">
                        <input type="hidden" name="sra" value="1">
                    </div>

                    <div class="greennature-form-fields">
                        <div class="six columns">
                            <div class="columns-wrap greennature-left">
                                <span class="greennature-head">Name *</span>
                                <input class="greennature-require" type="text" name="name">
                            </div>
                        </div>
                        <div class="six columns">
                            <div class="columns-wrap greennature-right">
                                <span class="greennature-head">Last Name *</span>
                                <input class="greennature-require" type="text" name="last-name">
                            </div>
                        </div>
                        <div class="clear"></div>
                        <div class="six columns">
                            <div class="columns-wrap greennature-left">
                                <span class="greennature-head">Email *</span>
                                <input class="greennature-require greennature-email" type="text" name="email">
                            </div>
                        </div>
                        <div class="six columns">
                            <div class="columns-wrap greennature-right">
                                <span class="greennature-head">Phone</span>
                                <input type="text" name="phone">
                            </div>
                        </div>
                        <div class="clear"></div>
                        <div class="six columns">
                            <div class="columns-wrap greennature-left">
                                <span class="greennature-head">Address</span>
                                <textarea name="address"></textarea>
                            </div>
                        </div>
                        <div class="six columns">
                            <div class="columns-wrap greennature-right">
                                <span class="greennature-head">Additional Note</span>
                                <textarea name="additional-note"></textarea>
                            </div>
                        </div>
                        <div class="clear"></div>
                    </div>

                    <div class="greennature-payment-method">
                        <img class="greennature-active" src="images/paypal.png" alt="paypal" /><img src="images/stripe.png" alt="stripe" />
                        <input type="hidden" name="payment-method" value="paypal" /> </div>
                    <div class="greennature-message"></div>
                    <div class="greennature-loading">Loading...</div>
                    <input type="submit" value="Donate Now" />
                </form>
            </div>
        </div>
    </div>
    <!-- body-wrapper -->

    <script type='text/javascript' src='js/jquery/jquery.js'></script>
    <script type='text/javascript' src='js/jquery/jquery-migrate.min.js'></script>
    <script>
        var ms_grabbing_curosr = 'plugins/masterslider/public/assets/css/common/grabbing.html',
            ms_grab_curosr = 'plugins/masterslider/public/assets/css/common/grab.html';
    </script>
    <script type='text/javascript' src='plugins/superfish/js/superfish.js'></script>
    <script type='text/javascript' src='js/hoverIntent.min.js'></script>
    <script type='text/javascript' src='plugins/dl-menu/modernizr.custom.js'></script>
    <script type='text/javascript' src='plugins/dl-menu/jquery.dlmenu.js'></script>
    <script type='text/javascript' src='plugins/jquery.easing.js'></script>
    <script type='text/javascript' src='plugins/fancybox/jquery.fancybox.pack.js'></script>
    <script type='text/javascript' src='plugins/fancybox/helpers/jquery.fancybox-media.js'></script>
    <script type='text/javascript' src='plugins/fancybox/helpers/jquery.fancybox-thumbs.js'></script>
    <script type='text/javascript' src='plugins/flexslider/jquery.flexslider.js'></script>
    <script type='text/javascript' src='plugins/jquery.isotope.min.js'></script>
    <script type='text/javascript' src='js/plugins.js'></script>
    <script type='text/javascript' src='plugins/masterslider/public/assets/js/masterslider.min.js'></script>
    <script type='text/javascript' src='plugins/jquery.transit.min.js'></script>
    <script type='text/javascript' src='plugins/gdlr-portfolio/gdlr-portfolio-script.js'></script>




    <script>
    (function ( $ ) {
        "use strict";

        $(function () {
            var masterslider_d1da = new MasterSlider();

            // slider controls
			masterslider_d1da.control('arrows'     ,{ autohide:true, overVideo:true  });
			masterslider_d1da.control('bullets'    ,{ autohide:false, overVideo:true, dir:'h', align:'bottom', space:6 , margin:25  });
            // slider setup
            masterslider_d1da.setup("slider_1", {
				width           : 1140,
				height          : 800,
				minHeight       : 0,
				space           : 0,
				start           : 1,
				grabCursor      : false,
				swipe           : true,
				mouse           : false,
				keyboard        : true,
				layout          : "fullwidth",
				wheel           : false,
				autoplay        : false,
                instantStartLayers:false,
				mobileBGVideo:false,
				loop            : true,
				shuffle         : false,
				preload         : 0,
				heightLimit     : true,
				autoHeight      : false,
				smoothHeight    : true,
				endPause        : false,
				overPause       : true,
				fillMode        : "fill",
				centerControls  : true,
				startOnAppear   : false,
				layersMode      : "center",
				autofillTarget  : "",
				hideLayers      : false,
				fullscreenMargin: 0,
				speed           : 20,
				dir             : "h",
				parallaxMode    : 'swipe',
				view            : "basic"
            });
            

            
            $("head").append( "<link rel='stylesheet' id='ms-fonts'  href='http://fonts.googleapis.com/css?family=Montserrat:regular,700%7CCrimson+Text:regular' type='text/css' media='all' />" );

            window.masterslider_instances = window.masterslider_instances || {};
            window.masterslider_instances["5_d1da"] = masterslider_d1da;
         });
        
    })(jQuery);
    </script> 
</body>

<!-- index19:10 GMT -->
</html><?php /**PATH C:\xampp\htdocs\adopt-tree\resources\views/index.blade.php ENDPATH**/ ?>