
<?php $__env->startSection('contentBody'); ?>
    <style>
        #map_canvas {
            width: 980px;
            height: 500px;
        }
        #current {
            padding-top: 25px;
        }
    </style>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Plantas</h1>
        
    </div>
        
    <form method=POST action="<?php echo e(route('plantaCreateUpdate')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <div class="form-group row" <?php if( Route::currentRouteName() != 'plantasShow'): ?> style="display:none" <?php endif; ?>">
                    <label for="idplantas" class="col-sm-2 col-md-2 col-lg-2 col-xl-2 col-form-label">Id</label>
                    <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10">
                        <input type="text" class="form-control" id="idplantas" name="idplantas" value="<?php echo e($planta->idplantas ?? ''); ?>" <?php if( Route::currentRouteName() == 'plantasShow'): ?> readonly="readonly <?php endif; ?>" >
                    </div>
                </div>

                <div class="form-group row">
                    <label for="idnombre" class="col-sm-2 col-md-2 col-lg-2 col-xl-2 col-form-label">Tipo Planta</label>
                    <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10">
                        <select name="idnombre" id="idnombre" class="form-control <?php $__errorArgs = ['idnombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="name" autofocus>
                            <option value="" disabled <?php if(old('idnombre') == ''): ?> selected <?php endif; ?>>Seleccione una opción</option>
                            <?php $__currentLoopData = $plantaPedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pp->idnombre); ?>" <?php if(old('idnombre') == "<?php echo e($pp->idnombre); ?>" OR (Route::currentRouteName() == 'plantasShow' AND "<?php echo e($pp->idnombre); ?>" == "<?php echo e($planta->idnombre); ?>")): ?> selected <?php endif; ?>><?php echo e($pp->nombre_comun); ?> - <?php echo e($pp->nombre_cientifico); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['idnombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <section>
                    <div id='map_canvas' style="width: 100%"></div>
                    <div id="current">
                        <?php if( Route::currentRouteName() == 'plantasShow'): ?>
                            <p class="text-success">Marcador posicionado: Latitud actual: <?php echo e(round($planta->latitud, 3) ?? ''); ?> Longitud actual : <?php echo e(round($planta->longitud, 3) ?? ''); ?></p>
                        <?php else: ?>
                            <h2 class="text-danger text-center">
                                Mueve el marcador...
                            </h2>
                        <?php endif; ?>
                        

                    </div>
                </section>
                
                <input type="text" id="latitud" name="latitud" style="display:none;" value="<?php echo e($planta->latitud ?? ''); ?>" required>
                <input type="text" id="longitud" name="longitud" style="display:none;" value="<?php echo e($planta->longitud ?? ''); ?>" required>
                
                
            <div class="form-group row text-center">
                <div class="col-sm-4 ">
                <button class="btn btn-success btn-icon-split" type="submit" id="btnCrear" name="btnCrear" <?php if( Route::currentRouteName() == 'plantasShow'): ?> disabled <?php endif; ?> >
                    <span class="icon text-white-50">
                        <i class="fas fa-check"></i>
                    </span>
                    <span class="text">Crear planta</span>    
                </button>
            </div>

            <div class="col-sm-4">
                    <button class="btn btn-warning btn-icon-split"  id="btnActualizar" name="btnActualizar" <?php if( Route::currentRouteName() != 'plantasShow'): ?> disabled <?php endif; ?>>
                        <span class="icon text-white-50">
                            <i class="fas fa-edit"></i>
                        </span>
                        <span class="text">Actualizar</span>    
                    </button>
                </div>
            <div class="col-sm-4">
                    <a  href="<?php echo e(route('plantas')); ?>" class="btn btn-primary btn-icon-split"  >
                        <span class="icon text-white-50">
                            <i class="fas fa-dumpster"></i>
                        </span>
                        <span class="text">Limpiar</span>    
                    </a>
            </div>
        </div>
    </form>
    <hr>
    <div class="row">
        <div class="col-12">
        <table class="table table-bordered" id="tabla">
            <thead>
                <tr>
                <th scope="col">#</th>
                <th scope="col">ID</th>
                <th scope="col">Nombre Comun</th>
                <th scope="col">Nombre Cientifico</th>
                <th scope="col">Latitud</th>
                <th scope="col">Longitud</th>
                <th scope="col">Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $plantas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><?php echo e($ps->idplantas); ?></td>
                        <td><?php echo e($ps->nombrePlanta->nombre_comun); ?></td>
                        <td><?php echo e($ps->nombrePlanta->nombre_cientifico); ?></td>
                        <td><?php echo e(round($ps->latitud, 3)); ?></td>
                        <td><?php echo e(round($ps->longitud, 3)); ?></td>
                        <td>
                            <a href="/dashboard/plantas/<?php echo e($ps->idnombre); ?>"  class="btn btn-warning btn-icon-split">
                                <span class="icon text-white-50">
                                    <i class="fas fa-edit"></i>
                                </span>
                                <span class="text">Editar</span>    
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAFkOsu7Q8aSe7u6XLzAKHDqN7Bq8BcvNk" async defer></script>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('inScript'); ?>
    $(document).ready( function () {
        $('#tabla').DataTable();
    });

    var map = new google.maps.Map(document.getElementById('map_canvas'), {
        zoom: 18,
        center: new google.maps.LatLng(5.210657, -74.900989),
        mapTypeId: 'satellite'
        //mapTypeId: google.maps.MapTypeId.ROADMAP
    });
    
    var myMarker = new google.maps.Marker({
        position: new google.maps.LatLng(<?php echo e($planta->latitud ?? '5.210657'); ?> , <?php echo e($planta->longitud ?? '-74.90098'); ?> ),
        draggable: true
    });
    
    google.maps.event.addListener(myMarker, 'dragend', function (evt) {
        document.getElementById('current').innerHTML = '<p class="text-success">Marcador posicionado: Latitud actual: ' + evt.latLng.lat().toFixed(3) + ' Longitud actual : ' + evt.latLng.lng().toFixed(3) + '</p>';
        $('#latitud').val(evt.latLng.lat());
        $('#longitud').val(evt.latLng.lng());
        console.log(evt.latLng.lat(), evt.latLng.lng());
        
    });
    
    google.maps.event.addListener(myMarker, 'dragstart', function (evt) {
        document.getElementById('current').innerHTML = '<p>Marcador arrastrando actualmente ...</p>';
    });
    
    map.setCenter(myMarker.position);
    myMarker.setMap(map);
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adopt-tree\resources\views/dashboard/plantas.blade.php ENDPATH**/ ?>