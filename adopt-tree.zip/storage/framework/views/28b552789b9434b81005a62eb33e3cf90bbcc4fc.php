
<?php $__env->startSection('contentBody'); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Ver usuarios</h1>
        
    </div>
        
    
    <div class="row">
        <div class="col-12">
        <table class="table table-bordered" id="tabla">
            <thead>
                <tr>
                <th scope="col">#</th>
                <th scope="col">Tipo Doc</th>
                <th scope="col">Numero Doc</th>
                <th scope="col">Nombres</th>
                <th scope="col">Apellidos</th>
                <th scope="col">Email</th>
                <th scope="col">Telefono</th>
                <th scope="col">Tipo Usuario</th>
                
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $usu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><?php echo e($usu->tipo_documento); ?></td>
                        <td><?php echo e($usu->cedula); ?></td>
                        <td><?php echo e($usu->nombre); ?></td>
                        <td><?php echo e($usu->apellido); ?></td>
                        <td><?php echo e($usu->email); ?></td>
                        <td><?php echo e($usu->telefono); ?></td>
                        <td><?php echo e($usu->getRole()); ?></td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inScript'); ?>
    $(document).ready( function () {
        $('#tabla').DataTable();
    });
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adopt-tree\resources\views/dashboard/verUsuario.blade.php ENDPATH**/ ?>