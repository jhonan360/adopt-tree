
<?php $__env->startSection('contentBody'); ?>
    <style>
        #map_canvas {
            width: 980px;
            height: 500px;
        }
        #current {
            padding-top: 25px;
        }
    </style>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Ver Bitacora</h1>
    </div>

    <form method=POST action="">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <div class="form-group row">
                    <label for="idplantas" class="col-sm-2 col-md-2 col-lg-2 col-xl-2 col-form-label">Id Planta</label>
                    <div class="col-sm-8 col-md-8 col-lg-8 col-xl-8">
                        <input type="text" class="form-control" id="idplantas" name="idplantas" value="<?php echo e($planta->idplantas ?? ''); ?>" <?php if( Route::currentRouteName() == 'hacerBitacoraShow'): ?> readonly="readonly <?php endif; ?>" required>
                    </div>
                    <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2">
                        <button class="btn btn-primary btn-icon-split" type="submit" id="btnBuscar" name="btnBuscar" onclick="buscarPlanta()">
                            <span class="icon text-white-50">
                                <i class="fas fa-search"></i>
                            </span>
                            <span class="text">Buscar</span>    
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>  
    
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="form-group row" <?php if( Route::currentRouteName() != 'verBitacoraShow'): ?> style="display:none" <?php endif; ?>">
                <label for="idnombre" class="col-sm-2 col-md-2 col-lg-2 col-xl-2 col-form-label">Nombre comun</label>
                <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10">
                    <input type="text" class="form-control" id="idnombre" name="idnombre" value="<?php echo e($planta->nombrePlanta->nombre_comun ?? ''); ?> - <?php echo e($planta->nombrePlanta->nombre_cientifico ?? ''); ?>" readonly="readonly" >
                </div>
            </div>
            <div class="form-group row" <?php if( Route::currentRouteName() != 'verBitacoraShow'): ?> style="display:none" <?php endif; ?>">
                <label for="nombre" class="col-sm-2 col-md-2 col-lg-2 col-xl-2 col-form-label">Nombre</label>
                <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10">
                    <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo e($planta->nombre ?? ''); ?>" readonly="readonly " >
                </div>
            </div>

            <div class="form-group row" <?php if( Route::currentRouteName() != 'verBitacoraShow'): ?> style="display:none" <?php endif; ?>">
                <label for="mensaje" class="col-sm-2 col-md-2 col-lg-2 col-xl-2 col-form-label">Mensaje</label>
                <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10">
                    <textarea class="form-control" name="mensaje" id="mensaje"  rows="3" readonly="readonly"><?php echo e($planta->mensaje ?? ''); ?></textarea>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row" <?php if( Route::currentRouteName() != 'verBitacoraShow'): ?> style="display:none" <?php endif; ?>">
        <hr>
        <div class="col-12">
        <table class="table table-bordered" id="tabla">
            <thead>
                <tr>
                <th scope="col">#</th>
                <th scope="col">Usuario</th>
                <th scope="col">Fecha Realización</th>
                <th scope="col">Hora Riego</th>
                <th scope="col">Poda</th>
                <th scope="col">Quimicos</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bitacoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bitacora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><?php echo e($bitacora->user->nombre); ?> <?php echo e($bitacora->user->apellido); ?></td>
                        <td><?php echo e($bitacora->created_at); ?></td>
                        <td><?php echo e($bitacora->hora_riego ?? ''); ?></td>
                        <td><?php echo e($bitacora->poda = 0 ? 'NO' : 'SI'); ?></td>
                        <td>
                            <?php $__currentLoopData = $bitacora->quimicosHasBitacoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $qhb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p style="font-size: 12px">
                                    <?php echo e($qhb->cantidad); ?> <?php echo e($qhb->medida->nombre); ?> de <?php echo e($qhb->quimico->nombre); ?>

                                </p>
                                <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('inScript'); ?>

    function buscarPlanta(){   
        event.preventDefault()
        var id = $('#idplantas').val();
        if(id != ''){
            window.location.replace("<?php echo e(route('verBitacora')); ?>/" + id);
        }
    }
    $(document).ready( function () {
        $('#tabla').DataTable();
    });

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adopt-tree\resources\views/dashboard/verBitacora.blade.php ENDPATH**/ ?>