
<?php $__env->startSection('content'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('content'); ?>
    <div class="content-wrapper">
        <div class="greennature-content">

            <!-- Above Sidebar Section-->

            <!-- Sidebar With Content Section-->
            <div class="with-sidebar-wrapper">
                <section id="content-section-1">
                    
                    <div style=" padding-top: 92px; padding-bottom: 0px; ">
                        <div id ="map" style="height: 63em; width: 100%; "> </div> 
                    </div>
                    <div class="clear"></div>
                </section>
            </div>
            <!-- Below Sidebar Section-->

        </div>
        <!-- greennature-content -->
        <div class="clear"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAFkOsu7Q8aSe7u6XLzAKHDqN7Bq8BcvNk&callback=initMap" async defer></script>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('inScript'); ?>
    
    var map;
    function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
            center: {lat: 5.210657, lng: -74.900989},
            zoom: 18,
            mapTypeId: 'satellite'
        });
        // marcadores
        <?php $__currentLoopData = $plantas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $planta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            var marker = new google.maps.Marker(
                {
                    position: {lat:  <?php echo e($planta->latitud); ?>, lng: <?php echo e($planta->longitud); ?>},
                    map: map,
                    title: '<?php echo e($planta->nombre); ?>'
                }
            );
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    }
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adopt-tree\resources\views/landing/maps.blade.php ENDPATH**/ ?>