
<?php $__env->startSection('contentBody'); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Planta Pedia</h1>
        
    </div>
        
    <form method=POST action="<?php echo e(route('plantaPediaCreateUpdate')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <div class="form-group row" <?php if( Route::currentRouteName() != 'plantaPediaShow'): ?> style="display:none" <?php endif; ?>">
                    <label for="idnombre" class="col-sm-2 col-md-2 col-lg-2 col-xl-2 col-form-label">Id</label>
                    <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10">
                        <input type="text" class="form-control" id="idnombre" name="idnombre" value="<?php echo e($plantaPedia->idnombre ?? ''); ?>" <?php if( Route::currentRouteName() == 'plantaPediaShow'): ?> readonly="readonly <?php endif; ?>" >
                    </div>
                </div>
                
                <div class="form-group row">
                    <label for="nombre_comun" class="col-sm-2 col-md-2 col-lg-2 col-xl-2 col-form-label">Nombre Comun</label>
                    <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10">
                        <input type="text" class="form-control <?php $__errorArgs = ['nombre_comun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nombre_comun" name="nombre_comun" placeholder="Escribe nombre comun de la planta" value="<?php echo e($plantaPedia->nombre_comun ?? ''); ?>" required>
                        <?php $__errorArgs = ['nombre_comun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="nombre_cientifico" class="col-sm-2 col-md-2 col-lg-2 col-xl-2 col-form-label">Nombre Cientifico</label>
                    <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10">
                        <input type="text" class="form-control <?php $__errorArgs = ['nombre_cientifico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nombre_cientifico" name="nombre_cientifico" placeholder="Escribe nombre cientifico de la planta" value="<?php echo e($plantaPedia->nombre_cientifico ?? ''); ?>" required>
                        <?php $__errorArgs = ['nombre_cientifico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                
                <div class="form-group row">
                    <label for="idtipo_planta" class="col-sm-2 col-md-2 col-lg-2 col-xl-2 col-form-label">Tipo Planta</label>
                    <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10">
                        <select name="idtipo_planta" id="idtipo_planta" class="form-control <?php $__errorArgs = ['idtipo_planta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="name" autofocus>
                            <option value="" disabled <?php if(old('idtipo_planta') == ''): ?> selected <?php endif; ?>>Seleccione una opción</option>
                            <?php $__currentLoopData = $tiposPlantas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tps->idtipo_planta); ?>" <?php if(old('idtipo_planta') == "<?php echo e($tps->idtipo_planta); ?>" OR (Route::currentRouteName() == 'plantaPediaShow' AND "<?php echo e($tps->idtipo_planta); ?>" == "<?php echo e($plantaPedia->idtipo_planta); ?>")): ?> selected <?php endif; ?>><?php echo e($tps->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['idtipo_planta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            <div class="form-group row">
                <label for="idclimas" class="col-sm-2 col-md-2 col-lg-2 col-xl-2 col-form-label">Clima</label>
                <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10">
                    <select name="idclimas" id="idclimas" class="form-control <?php $__errorArgs = ['idclimas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="name" autofocus>
                        <option value="" disabled <?php if(old('idclimas') == ''): ?> selected <?php endif; ?>>Seleccione una opción</option>
                        <?php $__currentLoopData = $climas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cli->idclimas); ?>" <?php if(old('idclimas') == "<?php echo e($cli->idclimas); ?>" OR (Route::currentRouteName() == 'plantaPediaShow' AND "<?php echo e($cli->idclimas); ?>" == "<?php echo e($plantaPedia->idclimas); ?>") ): ?> selected <?php endif; ?>><?php echo e($cli->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['idclimas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="detalle" class="col-sm-2 col-md-2 col-lg-2 col-xl-2 col-form-label">Detalle</label>
                <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10">
                    <textarea class="form-control <?php $__errorArgs = ['detalle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="detalle" id="detalle"  rows="3"><?php echo e($plantaPedia->detalle ?? ''); ?></textarea>
                    <?php $__errorArgs = ['detalle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group row text-center">
                <div class="col-sm-4 ">
                <button class="btn btn-success btn-icon-split" type="submit" id="btnCrear" name="btnCrear" <?php if( Route::currentRouteName() == 'plantaPediaShow'): ?> disabled <?php endif; ?> >
                    <span class="icon text-white-50">
                        <i class="fas fa-check"></i>
                    </span>
                    <span class="text">Crear registro</span>    
                </button>
            </div>
            <div class="col-sm-4">
                    <button class="btn btn-warning btn-icon-split"  id="btnActualizar" name="btnActualizar" <?php if( Route::currentRouteName() != 'plantaPediaShow'): ?> disabled <?php endif; ?>>
                        <span class="icon text-white-50">
                            <i class="fas fa-edit"></i>
                        </span>
                        <span class="text">Actualizar</span>    
                    </button>
                </div>
            <div class="col-sm-4">
                    <a  href="<?php echo e(route('plantaPedia')); ?>" class="btn btn-primary btn-icon-split"  >
                        <span class="icon text-white-50">
                            <i class="fas fa-dumpster"></i>
                        </span>
                        <span class="text">Limpiar</span>    
                    </a>
            </div>
        </div>
    </form>
    <hr>
    <div class="row">
        <div class="col-12">
        <table class="table table-bordered" id="tabla">
            <thead>
                <tr>
                <th scope="col">#</th>
                <th scope="col">Nombre Comun</th>
                <th scope="col">Nombre Cientifico</th>
                <th scope="col">Tipo Planta</th>
                <th scope="col">Clima</th>
                <th scope="col">Detalle</th>
                <th scope="col">Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $plantaPedias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><?php echo e($pps->nombre_comun); ?></td>
                        <td><?php echo e($pps->nombre_cientifico); ?></td>
                        <td><?php echo e($pps->tipoPlanta->nombre); ?></td>
                        <td><?php echo e($pps->clima->nombre); ?></td>
                        <td><?php echo e($pps->detalle); ?></td>
                        <td>
                            <a href="/dashboard/plantaPedia/<?php echo e($pps->idnombre); ?>"  class="btn btn-warning btn-icon-split">
                                <span class="icon text-white-50">
                                    <i class="fas fa-edit"></i>
                                </span>
                                <span class="text">Editar</span>    
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inScript'); ?>
    $(document).ready( function () {
        $('#tabla').DataTable();
    });
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adopt-tree\resources\views/dashboard/plantaPedia.blade.php ENDPATH**/ ?>