@extends('layouts.index')
@section('content')
    <div class="content-wrapper">
        <div class="greennature-content">

            <!-- Above Sidebar Section-->

            <!-- Sidebar With Content Section-->
            <div class="with-sidebar-wrapper">
                <section id="content-section-1">
                    <div class="greennature-parallax-wrapper  gdlr-show-all"  data-bgspeed="0" style=" padding-top: 280px; padding-bottom: 160px; ">
                        <h1>Vista para mostrar arboles</h1>
                    </div>
                    <div class="clear"></div>
                </section>
            </div>
            <!-- Below Sidebar Section-->

        </div>
        <!-- greennature-content -->
        <div class="clear"></div>
    </div>

@endsection
@section('script')

@endsection

@section('inScript')

@endsection